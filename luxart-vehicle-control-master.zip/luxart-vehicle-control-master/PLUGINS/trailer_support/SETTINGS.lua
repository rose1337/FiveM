--------------------TRAILER SUPPORT SETTINGS---------------------
trailer_masterswitch = true
--	Determines if trailer_support plugin can be activated.

--[[ Documentation / Wiki: https://github.com/TrevorBarns/luxart-vehicle-control/wiki/Trailer-Support ]]

TRAILERS = { }
